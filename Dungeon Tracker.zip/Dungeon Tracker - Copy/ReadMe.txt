DnD dungeon Tracker/Designer - 

Load using the 'Level Editor' executable

HEY!

Playing Dungeons and Dragons and varius other RPG/TTPRPG over the years has made me realise that sometimes the life of a Dungeon Master is difficult(especially for lazy people like me).
I noticed that it gets even harder to play when you are on time restraints(especially for unorganised people like me), 
the worst is when you are in the middle of a session of dungeon/raid or just exploring and you run out of time - sometimes you forget things about the event which sucks 
for when the next time you meet up and play and have to spend lots of times trying to remember everything and find your notes with said info.
I've had times where either myself or the DM loses a sheet with the dungeon info on it and I wanted to remedy that.

So, I decided to make this simple little tool in C# using Visual Studio to make the lives of DM's easier. 

You can use this tool to draw rooms in the box on the left hand side by click and drag. click on the room to fill in the information on the right side.
You can save and load the information and the rooms via File located in the top left of the application.


Please note that this is my first windows application and first real experience with C#. I made the whole application myself, including custom controllers and Icon.
Also note that I tried to make this pretty flexible so that you can use it in games that arent DnD or table top RPG's.


Was made early 2017 by Isaac Bowes (hey that's me!)
Contact me VIA
Twitter - @sorason12 
My Website - https://isaacbowes.wordpress.com/
or my email address - isaac.bowes@hotmail.com

This was made with the help and assistance of DR. Mike Cooper from AIE Adelaide.